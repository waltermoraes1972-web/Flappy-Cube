package com.Flappybird.LeRED;

import java.util.ArrayList;

/**
 * Lógica do Flappy Cube portada 1:1 do HTML original (sem nenhuma dependência de Android).
 * Todas as constantes, ordem de sorteios e fórmulas seguem o JavaScript original.
 */
public final class GameCore {

    public interface Rnd { double next(); }

    public interface Listener { void onGameOver(int score, int best); }

    public static final String[] SKIN_NAMES = {
        "Clássico", "Azul", "Vermelho", "Roxo", "Verde", "Rosa", "Laranja", "Dark"
    };
    public static final int[] SKIN_COLORS = {
        0xFFFFE13B, 0xFF37A9FF, 0xFFFF4848, 0xFFBA69FF,
        0xFF49DF76, 0xFFFF83CF, 0xFFFF9C35, 0xFF303744
    };

    public static final int MENU = 0, PLAYING = 1, OVER = 2;

    public static final class Cube { public double x, y, size, vy, rotation; }
    public static final class Pipe { public double x, topH, gap, width; public boolean passed; }
    public static final class Particle { public double x, y, vx, vy, life, size; public int color; }
    public static final class Cloud { public double x, y, s; }

    public double W = 400;
    public double H = 700;

    public Cube cube;
    public ArrayList<Pipe> pipes = new ArrayList<>();
    public ArrayList<Particle> particles = new ArrayList<>();
    public ArrayList<Cloud> clouds = new ArrayList<>();

    public int score = 0;
    public int best = 0;
    public int selectedSkin = 0;
    public int state = MENU;
    public double speed = 2.7;
    public double spawnTimer = 0;
    public double elapsed = 0;
    public double lastTime = 0;

    private final Rnd rnd;
    public Listener listener;

    public GameCore(Rnd rnd) {
        this.rnd = rnd;
    }

    public void resize(double w, double h) {
        W = w;
        H = h;
        createClouds();
    }

    public void initMenuCube() {
        cube = new Cube();
        cube.x = W * 0.5;
        cube.y = H * 0.61;
        cube.size = 35;
        cube.vy = 0;
        cube.rotation = 0;
    }

    private void createClouds() {
        clouds = new ArrayList<>();
        for (int i = 0; i < 7; i++) {
            Cloud c = new Cloud();
            c.x = rnd.next() * W;
            c.y = 45 + rnd.next() * H * 0.48;
            c.s = 0.6 + rnd.next() * 0.8;
            clouds.add(c);
        }
    }

    public double groundY() {
        return H - Math.max(65, H * 0.12);
    }

    public void resetGame() {
        score = 0;
        speed = 2.7;
        spawnTimer = 0;
        pipes = new ArrayList<>();
        particles = new ArrayList<>();
        elapsed = 0;

        cube = new Cube();
        cube.x = W * 0.27;
        cube.y = H * 0.43;
        cube.size = Math.max(27, Math.min(34, W * 0.085));
        cube.vy = 0;
        cube.rotation = 0;

        state = PLAYING;
    }

    public void startGame() {
        resetGame();
        flap();
    }

    public void flap() {
        if (state != PLAYING) return;
        cube.vy = -6.1;
        burst(cube.x, cube.y, SKIN_COLORS[selectedSkin], 4);
    }

    private void spawnPipe() {
        double gap = Math.max(145, Math.min(190, H * 0.25));
        double topMargin = 70;
        double bottomMargin = groundY() - 55;
        double available = bottomMargin - topMargin - gap;

        double topH = topMargin + rnd.next() * Math.max(1, available);

        Pipe p = new Pipe();
        p.x = W + 20;
        p.topH = topH;
        p.gap = gap;
        p.width = Math.max(58, W * 0.16);
        p.passed = false;
        pipes.add(p);
    }

    private void burst(double x, double y, int color, int amount) {
        for (int i = 0; i < amount; i++) {
            Particle p = new Particle();
            p.x = x;
            p.y = y;
            p.vx = (rnd.next() - 0.5) * 4;
            p.vy = (rnd.next() - 0.5) * 4;
            p.life = 25 + rnd.next() * 15;
            p.color = color;
            p.size = 2 + rnd.next() * 4;
            particles.add(p);
        }
    }

    private void endGame() {
        if (state != PLAYING) return;

        state = OVER;
        burst(cube.x, cube.y, SKIN_COLORS[selectedSkin], 18);

        if (score > best) {
            best = score;
        }
        if (listener != null) listener.onGameOver(score, best);
    }

    private boolean collidesPipe(Pipe p) {
        double s = cube.size;
        double left = cube.x - s * 0.42;
        double right = cube.x + s * 0.42;
        double top = cube.y - s * 0.42;
        double bottom = cube.y + s * 0.42;

        if (right < p.x || left > p.x + p.width) return false;

        return top < p.topH || bottom > p.topH + p.gap;
    }

    public void update(double dt) {
        elapsed += dt;

        for (Cloud c : clouds) {
            c.x -= 0.15 * c.s * dt;
            if (c.x < -100) {
                c.x = W + 80;
                c.y = 45 + rnd.next() * H * 0.48;
            }
        }

        for (Particle p : particles) {
            p.x += p.vx * dt;
            p.y += p.vy * dt;
            p.vy += 0.12 * dt;
            p.life -= dt;
        }
        ArrayList<Particle> alive = new ArrayList<>();
        for (Particle p : particles) if (p.life > 0) alive.add(p);
        particles = alive;

        if (state != PLAYING) return;

        speed = Math.min(4.6, 2.7 + score * 0.035);

        cube.vy += 0.34 * dt;
        cube.y += cube.vy * dt;
        cube.rotation = Math.max(-0.45, Math.min(1.15, cube.vy * 0.075));

        spawnTimer += dt;

        if (spawnTimer > 92) {
            spawnPipe();
            spawnTimer = 0;
        }

        for (Pipe p : pipes) {
            p.x -= speed * dt;

            if (!p.passed && p.x + p.width < cube.x) {
                p.passed = true;
                score++;
            }

            if (collidesPipe(p)) {
                endGame();
                return;
            }
        }

        ArrayList<Pipe> keep = new ArrayList<>();
        for (Pipe p : pipes) if (p.x + p.width > -20) keep.add(p);
        pipes = keep;

        if (cube.y - cube.size / 2 < 0 ||
            cube.y + cube.size / 2 > groundY()) {
            endGame();
        }
    }

    /** Animação do cubo na tela inicial (usa o relógio em ms, como performance.now()). */
    private void menuAnimation(double nowMs) {
        if (state == MENU && cube != null) {
            cube.y = H * 0.61 + Math.sin(nowMs / 250) * 9;
            cube.rotation = Math.sin(nowMs / 400) * 0.08;
        }
    }

    /** Equivalente ao mainLoop(timestamp) do original. */
    public void frame(double timestampMs) {
        double dt = lastTime > 0
            ? Math.min((timestampMs - lastTime) / 16.667, 2)
            : 1;

        lastTime = timestampMs;

        if (state == MENU) {
            menuAnimation(timestampMs);

            for (Cloud c : clouds) {
                c.x -= 0.15 * c.s * dt;
                if (c.x < -100) c.x = W + 80;
            }

            elapsed += dt;
        } else {
            update(dt);
        }
    }
}
