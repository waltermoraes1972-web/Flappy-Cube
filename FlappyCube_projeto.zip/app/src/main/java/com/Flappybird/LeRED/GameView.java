package com.Flappybird.LeRED;

import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Canvas;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;
import android.graphics.Shader;
import android.graphics.Typeface;
import android.os.SystemClock;
import android.view.MotionEvent;
import android.view.View;

/**
 * Tela do jogo toda desenhada em Canvas (sem WebView / HTML).
 * As medidas estão em "dp", que equivalem aos "px CSS" do jogo original.
 */
public class GameView extends View {

    private static final int ID_PLAY = 0, ID_RESTART = 1, ID_BACK = 2, ID_SKIN = 10;

    private final GameCore core;
    private final SharedPreferences prefs;

    private float density = 1f;
    private double viewW = 0, viewH = 0;
    private float ox = 0, oy = 0;

    private boolean overVisible = false;
    private long overAt = 0;
    private int finalScore = 0, finalBest = 0;
    private int pressed = -1;

    private final RectF playR = new RectF();
    private final RectF restartR = new RectF();
    private final RectF backR = new RectF();
    private final RectF[] skinR = new RectF[8];

    private final Paint fill = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint line = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint tp = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Path path = new Path();
    private final RectF tmp = new RectF();

    public GameView(Context context) {
        super(context);
        for (int i = 0; i < 8; i++) skinR[i] = new RectF();

        prefs = context.getSharedPreferences("flappyCube", Context.MODE_PRIVATE);
        core = new GameCore(Math::random);
        core.best = prefs.getInt("best", 0);
        core.listener = new GameCore.Listener() {
            @Override public void onGameOver(int score, int best) {
                finalScore = score;
                finalBest = best;
                prefs.edit().putInt("best", best).apply();
                overVisible = false;
                overAt = SystemClock.uptimeMillis() + 350;
            }
        };

        line.setStyle(Paint.Style.STROKE);
        line.setStrokeMiter(10f);
        setFocusable(true);
    }

    @Override
    protected void onSizeChanged(int w, int h, int oldw, int oldh) {
        super.onSizeChanged(w, h, oldw, oldh);
        if (w <= 0 || h <= 0) return;
        density = getResources().getDisplayMetrics().density;
        viewW = w / density;
        viewH = h / density;

        double gw = Math.min(viewW, 480);
        double gh = Math.min(viewH, 760);
        boolean first = core.cube == null;
        core.resize(gw, gh);
        if (first) core.initMenuCube();

        ox = (float) ((viewW - gw) / 2);
        oy = (float) ((viewH - gh) / 2);
    }

    // ------------------------------------------------------------------ ações

    private void startGame() {
        core.startGame();
        overVisible = false;
    }

    private void click(int id) {
        if (id == ID_PLAY || id == ID_RESTART) {
            startGame();
        } else if (id == ID_BACK) {
            core.state = GameCore.MENU;
            overVisible = false;
        } else if (id >= ID_SKIN) {
            core.selectedSkin = id - ID_SKIN;
        }
    }

    private int hit(float x, float y) {
        if (core.state == GameCore.MENU) {
            if (playR.contains(x, y)) return ID_PLAY;
            for (int i = 0; i < 8; i++) if (skinR[i].contains(x, y)) return ID_SKIN + i;
        } else if (core.state == GameCore.OVER && overVisible) {
            if (restartR.contains(x, y)) return ID_RESTART;
            if (backR.contains(x, y)) return ID_BACK;
        }
        return -1;
    }

    public boolean handleKey(int keyCode) {
        if (keyCode == android.view.KeyEvent.KEYCODE_SPACE
                || keyCode == android.view.KeyEvent.KEYCODE_DPAD_UP) {
            if (core.state == GameCore.PLAYING) {
                core.flap();
            } else if (core.state == GameCore.OVER) {
                startGame();
            }
            return true;
        }
        return false;
    }

    @Override
    public boolean onTouchEvent(MotionEvent e) {
        int action = e.getActionMasked();
        int idx = e.getActionIndex();
        float gx = e.getX(idx) / density - ox;
        float gy = e.getY(idx) / density - oy;

        switch (action) {
            case MotionEvent.ACTION_DOWN:
                if (core.state == GameCore.PLAYING) {
                    core.flap();
                } else {
                    pressed = hit(gx, gy);
                }
                return true;
            case MotionEvent.ACTION_POINTER_DOWN:
                if (core.state == GameCore.PLAYING) core.flap();
                return true;
            case MotionEvent.ACTION_UP:
                if (pressed >= 0 && hit(gx, gy) == pressed) click(pressed);
                pressed = -1;
                return true;
            case MotionEvent.ACTION_CANCEL:
                pressed = -1;
                return true;
            default:
                return true;
        }
    }

    // ----------------------------------------------------------------- desenho

    @Override
    protected void onDraw(Canvas c) {
        long now = SystemClock.uptimeMillis();
        core.frame(now);

        if (core.state == GameCore.OVER && !overVisible && overAt > 0 && now >= overAt) {
            overVisible = true;
        }

        c.drawColor(0xFF70C5CE);
        c.save();
        c.scale(density, density);
        c.translate(ox, oy);
        c.clipRect(0f, 0f, (float) core.W, (float) core.H);

        renderGame(c);

        if (core.state == GameCore.MENU) {
            drawMenu(c);
        } else if (core.state == GameCore.OVER && overVisible) {
            drawOver(c);
        }

        c.restore();
        postInvalidateOnAnimation();
    }

    private void renderGame(Canvas c) {
        drawBackground(c);

        for (GameCore.Pipe p : core.pipes) drawPipe(c, p);

        fill.setShader(null);
        fill.setStyle(Paint.Style.FILL);
        for (GameCore.Particle p : core.particles) {
            fill.setColor(p.color);
            fill.setAlpha((int) Math.round(Math.max(0, Math.min(1, p.life / 35)) * 255));
            c.drawRect((float) p.x, (float) p.y, (float) (p.x + p.size), (float) (p.y + p.size), fill);
        }
        fill.setAlpha(255);

        drawCube(c);
        drawGround(c);
        drawScore(c);

        if (core.state == GameCore.MENU && core.cube != null) {
            setText(16f, true, 0f);
            tp.setTextAlign(Paint.Align.CENTER);
            tp.setColor(0xFFFFFFFF);
            c.drawText("ESCOLHA SUA SKIN E JOGUE!", (float) (core.W / 2), (float) (core.H * 0.77), tp);
        }
    }

    private void drawBackground(Canvas c) {
        float W = (float) core.W, H = (float) core.H;
        fill.setStyle(Paint.Style.FILL);
        fill.setShader(new LinearGradient(0, 0, 0, H, 0xFF70C5CE, 0xFFB3E8ED, Shader.TileMode.CLAMP));
        c.drawRect(0, 0, W, H, fill);
        fill.setShader(null);

        for (GameCore.Cloud cl : core.clouds) drawCloud(c, (float) cl.x, (float) cl.y, (float) cl.s);

        // Montanhas distantes
        float gy = (float) core.groundY();
        fill.setColor(0xFF9BD9AA);
        path.reset();
        path.moveTo(0, gy);
        for (float x = 0; x <= W + 40; x += 40) {
            float y = (float) (gy - 65 - Math.sin(x * 0.025) * 25 - Math.cos(x * 0.043) * 15);
            path.lineTo(x, y);
        }
        path.lineTo(W, gy);
        path.close();
        c.drawPath(path, fill);
    }

    private void ellipse(float cx, float cy, float rx, float ry, boolean first) {
        tmp.set(cx - rx, cy - ry, cx + rx, cy + ry);
        path.arcTo(tmp, 0f, 360f, first);
    }

    private void drawCloud(Canvas c, float x, float y, float s) {
        fill.setColor(0xD9FFFFFF);
        path.reset();
        ellipse(x, y, 25 * s, 13 * s, true);
        ellipse(x + 17 * s, y - 7 * s, 19 * s, 17 * s, false);
        ellipse(x + 34 * s, y, 25 * s, 12 * s, false);
        c.drawPath(path, fill);
    }

    private void drawPipe(Canvas c, GameCore.Pipe p) {
        float x = (float) p.x;
        float w = (float) p.width;
        float topH = (float) p.topH;
        float bottomY = (float) (p.topH + p.gap);
        float gy = (float) core.groundY();

        Shader green = new LinearGradient(x, 0, x + w, 0,
                new int[]{0xFF3B9E26, 0xFF7EE641, 0xFF50C42D, 0xFF287C20},
                new float[]{0f, 0.25f, 0.65f, 1f}, Shader.TileMode.CLAMP);

        float lipH = 19;
        float lipW = w + 12;
        float lipX = x - 6;

        fill.setStyle(Paint.Style.FILL);
        fill.setShader(green);

        // Torre superior
        c.drawRect(x, 0, x + w, topH - lipH, fill);

        // Triângulo na ponta superior
        path.reset();
        path.moveTo(x, topH - lipH);
        path.lineTo(x + w / 2, topH - lipH - 24);
        path.lineTo(x + w, topH - lipH);
        path.close();
        c.drawPath(path, fill);

        c.drawRect(lipX, topH - lipH, lipX + lipW, topH, fill);

        fill.setShader(null);
        fill.setColor(0xFFA5F76B);
        c.drawRect(lipX + 5, topH - lipH + 3, lipX + 5 + 6, topH - lipH + 3 + (lipH - 6), fill);

        // Torre inferior
        fill.setShader(green);
        c.drawRect(x, bottomY + lipH, x + w, bottomY + lipH + (gy - bottomY - lipH), fill);

        // Triângulo na base da torre inferior
        path.reset();
        path.moveTo(x, bottomY + lipH);
        path.lineTo(x + w / 2, bottomY + lipH + 24);
        path.lineTo(x + w, bottomY + lipH);
        path.close();
        c.drawPath(path, fill);

        c.drawRect(lipX, bottomY, lipX + lipW, bottomY + lipH, fill);

        fill.setShader(null);
        fill.setColor(0xFFA5F76B);
        c.drawRect(lipX + 5, bottomY + 3, lipX + 5 + 6, bottomY + 3 + (lipH - 6), fill);

        // Contorno
        line.setColor(0xFF267B21);
        line.setStrokeWidth(2f);
        c.drawRect(x, 0, x + w, topH - lipH, line);
        c.drawRect(x, bottomY + lipH, x + w, bottomY + lipH + (gy - bottomY - lipH), line);
        c.drawRect(lipX, topH - lipH, lipX + lipW, topH, line);
        c.drawRect(lipX, bottomY, lipX + lipW, bottomY + lipH, line);
    }

    private void drawCube(Canvas c) {
        GameCore.Cube cube = core.cube;
        if (cube == null) return;

        float s = (float) cube.size;

        c.save();
        c.translate((float) cube.x, (float) cube.y);
        c.rotate((float) Math.toDegrees(cube.rotation));

        fill.setShader(null);
        fill.setStyle(Paint.Style.FILL);

        // Sombra
        fill.setColor(0x22000000);
        c.drawRect(-s / 2 + 3, -s / 2 + 4, -s / 2 + 3 + s, -s / 2 + 4 + s, fill);

        // Corpo
        fill.setColor(GameCore.SKIN_COLORS[core.selectedSkin]);
        c.drawRect(-s / 2, -s / 2, s / 2, s / 2, fill);

        // Brilho
        fill.setColor(0x55FFFFFF);
        c.drawRect(-s / 2 + 3, -s / 2 + 3, -s / 2 + 3 + (s - 6), -s / 2 + 3 + 5, fill);

        // Borda
        line.setColor(0xFF443D2C);
        line.setStrokeWidth(2.5f);
        c.drawRect(-s / 2, -s / 2, s / 2, s / 2, line);

        // Olhos
        fill.setColor(0xFFFFFFFF);
        c.drawRect(-s * 0.25f, -s * 0.15f, -s * 0.25f + s * 0.23f, -s * 0.15f + s * 0.27f, fill);
        c.drawRect(s * 0.08f, -s * 0.15f, s * 0.08f + s * 0.23f, -s * 0.15f + s * 0.27f, fill);

        fill.setColor(0xFF222222);
        c.drawRect(-s * 0.17f, -s * 0.08f, -s * 0.17f + s * 0.1f, -s * 0.08f + s * 0.15f, fill);
        c.drawRect(s * 0.16f, -s * 0.08f, s * 0.16f + s * 0.1f, -s * 0.08f + s * 0.15f, fill);

        // Boca
        line.setColor(0xFF443D2C);
        line.setStrokeWidth(2f);
        c.drawLine(-s * 0.15f, s * 0.23f, s * 0.15f, s * 0.23f, line);

        c.restore();
    }

    private void drawGround(Canvas c) {
        float W = (float) core.W, H = (float) core.H;
        float gy = (float) core.groundY();

        fill.setShader(null);
        fill.setStyle(Paint.Style.FILL);

        fill.setColor(0xFFDED895);
        c.drawRect(0, gy, W, gy + (H - gy), fill);

        fill.setColor(0xFF75D542);
        c.drawRect(0, gy, W, gy + 13, fill);

        fill.setColor(0xFF479D32);
        c.drawRect(0, gy + 13, W, gy + 13 + 4, fill);

        // Textura móvel
        fill.setColor(0xFFB7AE73);
        float offset = (float) ((core.elapsed * 2.7) % 32);
        for (float x = -32; x < W + 32; x += 32) {
            c.drawRect(x - offset, gy + 25, x - offset + 16, gy + 25 + 3, fill);
        }
    }

    private void drawScore(Canvas c) {
        if (core.state != GameCore.PLAYING) return;

        String t = String.valueOf(core.score);
        float cx = (float) (core.W / 2);

        setText(48f, true, 0f);
        tp.setTextAlign(Paint.Align.CENTER);
        tp.setStyle(Paint.Style.STROKE);
        tp.setStrokeWidth(5f);
        tp.setStrokeMiter(10f);
        tp.setColor(0xFF526B45);
        c.drawText(t, cx, 76f, tp);

        tp.setStyle(Paint.Style.FILL);
        tp.setColor(0xFFFFFFFF);
        c.drawText(t, cx, 76f, tp);
    }

    // ------------------------------------------------------------ interface (UI)

    private void setText(float size, boolean bold, float letterSpacingPx) {
        tp.setStyle(Paint.Style.FILL);
        tp.setTextSize(size);
        tp.setTypeface(bold ? Typeface.DEFAULT_BOLD : Typeface.DEFAULT);
        tp.setLetterSpacing(size > 0 ? letterSpacingPx / size : 0f);
        tp.setTextAlign(Paint.Align.LEFT);
    }

    private float tw(String s, float size, boolean bold) {
        setText(size, bold, 0f);
        return tp.measureText(s);
    }

    private float lineH(float size, boolean bold) {
        setText(size, bold, 0f);
        Paint.FontMetrics fm = tp.getFontMetrics();
        return fm.descent - fm.ascent + fm.leading;
    }

    private float asc(float size, boolean bold) {
        setText(size, bold, 0f);
        return -tp.getFontMetrics().ascent;
    }

    private void text(Canvas c, String s, float cx, float baseline, float size, boolean bold,
                      int color, int shadow, float sdx, float sdy) {
        setText(size, bold, 0f);
        tp.setTextAlign(Paint.Align.CENTER);
        if (shadow != 0) {
            tp.setColor(shadow);
            c.drawText(s, cx + sdx, baseline + sdy, tp);
        }
        tp.setColor(color);
        c.drawText(s, cx, baseline, tp);
    }

    private void round(Canvas c, float x, float y, float w, float h, float r, int color) {
        fill.setShader(null);
        fill.setStyle(Paint.Style.FILL);
        fill.setColor(color);
        c.drawRoundRect(x, y, x + w, y + h, r, r, fill);
    }

    private void panel(Canvas c, float x, float y, float w, float h) {
        round(c, x, y + 5, w, h, 12, 0xFF9A7546);
        round(c, x, y, w, h, 12, 0xFF7D542E);
        round(c, x + 3, y + 3, w - 6, h - 6, 9, 0xFFDED895);
    }

    private void mainButton(Canvas c, RectF r, String label, float size, boolean isPressed, float padV) {
        float dy = isPressed ? 4 : 0;
        float sh = isPressed ? 1 : 5;
        round(c, r.left, r.top + dy + sh, r.width(), r.height(), 10, 0xFF77512C);
        round(c, r.left, r.top + dy, r.width(), r.height(), 10, 0xFF77512C);

        fill.setStyle(Paint.Style.FILL);
        fill.setShader(new LinearGradient(0, r.top + dy + 3, 0, r.bottom + dy - 3,
                0xFFB6F75C, 0xFF65CB30, Shader.TileMode.CLAMP));
        c.drawRoundRect(r.left + 3, r.top + dy + 3, r.right - 3, r.bottom + dy - 3, 7, 7, fill);
        fill.setShader(null);

        float baseline = r.top + dy + 3 + padV + asc(size, true);
        text(c, label, r.centerX(), baseline, size, true, 0xFFFFFFFF, 0xFF397526, 2, 2);
    }

    private void skinButton(Canvas c, int i, RectF r, boolean selected) {
        float dy = selected ? -2 : 0;
        int border = selected ? 0xFF278C32 : 0xFFB9AA72;
        int bg = selected ? 0xFFB9F49D : 0xFFF7EFC4;

        round(c, r.left, r.top + dy, r.width(), r.height(), 8, border);
        round(c, r.left + 3, r.top + dy + 3, r.width() - 6, r.height() - 6, 5, bg);

        float px = r.left + (r.width() - 31) / 2;
        float py = r.top + dy + 3 + 7;
        round(c, px, py, 31, 31, 5, 0xFF333333);
        round(c, px + 2, py + 2, 27, 27, 3, GameCore.SKIN_COLORS[i]);

        float baseline = py + 31 + 5 + asc(10f, true);
        text(c, GameCore.SKIN_NAMES[i], r.centerX(), baseline, 10f, true, 0xFF654B2E, 0, 0, 0);
    }

    private void drawMenu(Canvas c) {
        float W = (float) core.W;
        boolean compact = viewH <= 650;
        float padTop = compact ? 8 : 25;
        float contentW = W - 30;
        float y = padTop;

        // Título
        float h1 = compact ? 34f : (float) Math.max(34, Math.min(48, viewW * 0.10));
        y += compact ? 5 : 20;
        float h1Base = y + asc(h1, true);
        drawTitle(c, "FLAPPY CUBE", W / 2, h1Base, h1);
        y += lineH(h1, true) + 8;

        // Subtítulo
        text(c, "O cubo mais voador do mundo!", W / 2, y + asc(15f, true), 15f, true,
                0xFFFFFFFF, 0xFF536B5D, 2, 3);
        y += lineH(15f, true) + 12;

        // Painel de skins
        float panelW = Math.min(contentW, 350);
        float px = (W - panelW) / 2;
        float pad = compact ? 8 : 14;
        float gap = compact ? 5 : 9;
        float labelH = lineH(17f, true);
        float innerW = panelW - 6 - 2 * pad;
        float cellW = (innerW - 3 * gap) / 4;
        float cellH = 3 + 7 + 31 + 5 + lineH(10f, true) + 7 + 3;
        float panelH = 6 + 2 * pad + labelH + 12 + 2 * cellH + gap;

        panel(c, px, y, panelW, panelH);
        text(c, "\uD83C\uDFA8 ESCOLHA SUA SKIN", W / 2, y + 3 + pad + asc(17f, true), 17f, true,
                0xFF654B2E, 0, 0, 0);

        float gx0 = px + 3 + pad;
        float gy0 = y + 3 + pad + labelH + 12;
        for (int i = 0; i < 8; i++) {
            float x0 = gx0 + (i % 4) * (cellW + gap);
            float y0 = gy0 + (i / 4) * (cellH + gap);
            skinR[i].set(x0, y0, x0 + cellW, y0 + cellH);
            skinButton(c, i, skinR[i], i == core.selectedSkin);
        }
        y += panelH;

        // Botão PLAY
        float padV = compact ? 9 : 12;
        float padH = compact ? 35 : 42;
        y += compact ? 12 : 19;
        String play = "\u25B6 PLAY";
        float bw = tw(play, 25f, true) + 2 * padH + 6;
        float bh = 6 + 2 * padV + lineH(25f, true);
        playR.set((W - bw) / 2, y, (W + bw) / 2, y + bh);
        mainButton(c, playR, play, 25f, pressed == ID_PLAY, padV);
        y += bh;

        // Dicas
        float hintTop = compact ? 10 : 17;
        y += hintTop;
        text(c, "TOQUE PARA PULAR \u2022 DESVIE DAS TORRES!", W / 2, y + asc(12f, true), 12f, true,
                0xFFFFFFFF, 0xFF527B76, 1, 2);
        y += lineH(12f, true) + hintTop;
        text(c, "RECORDE: " + core.best, W / 2, y + asc(12f, true), 12f, true,
                0xFFFFFFFF, 0xFF527B76, 1, 2);
    }

    private void drawTitle(Canvas c, String s, float cx, float baseline, float size) {
        setText(size, true, 1f);
        tp.setTextAlign(Paint.Align.CENTER);

        tp.setColor(0xFF536B5D);
        c.drawText(s, cx + 2, baseline + 3, tp);

        tp.setColor(0xFFFFFFFF);
        c.drawText(s, cx, baseline, tp);

        tp.setStyle(Paint.Style.STROKE);
        tp.setStrokeWidth(1f);
        tp.setStrokeMiter(10f);
        tp.setColor(0xFF47734B);
        c.drawText(s, cx, baseline, tp);
        tp.setStyle(Paint.Style.FILL);
    }

    private void drawOver(Canvas c) {
        float W = (float) core.W, H = (float) core.H;
        boolean compact = viewH <= 650;
        float padTop = compact ? 8 : 25;

        fill.setShader(null);
        fill.setStyle(Paint.Style.FILL);
        fill.setColor(0x44000000);
        c.drawRect(0, 0, W, H, fill);

        float pad = compact ? 8 : 14;
        float mt = compact ? 12 : 19;
        float padV1 = compact ? 9 : 12;
        float padH1 = compact ? 35 : 42;

        float h2H = lineH(37f, true);
        float resultLH = 23f * 1.8f;
        float panelW = Math.min(W - 30, 350);
        float panelH = 6 + 2 * pad + 2 * resultLH;

        String again = "\u21BB JOGAR DE NOVO";
        float b1W = tw(again, 25f, true) + 2 * padH1 + 6;
        float b1H = 6 + 2 * padV1 + lineH(25f, true);

        String menu = "\uD83C\uDFE0 MENU";
        float b2W = tw(menu, 17f, true) + 2 * 20 + 6;
        float b2H = 6 + 2 * 10 + lineH(17f, true);

        float total = h2H + 18 + panelH + mt + b1H + mt + b2H;
        float y = padTop + ((H - 2 * padTop) - total) / 2;

        text(c, "GAME OVER!", W / 2, y + asc(37f, true), 37f, true, 0xFFFFFFFF, 0xFF536B5D, 2, 3);
        y += h2H + 18;

        float px = (W - panelW) / 2;
        panel(c, px, y, panelW, panelH);
        Paint.FontMetrics fm;
        setText(23f, true, 0f);
        fm = tp.getFontMetrics();
        float base0 = y + 3 + pad + (resultLH - (fm.descent - fm.ascent)) / 2 - fm.ascent;
        text(c, "PONTOS: " + finalScore, W / 2, base0, 23f, true, 0xFF654B2E, 0, 0, 0);
        text(c, "RECORDE: " + finalBest, W / 2, base0 + resultLH, 23f, true, 0xFF654B2E, 0, 0, 0);
        y += panelH;

        y += mt;
        restartR.set((W - b1W) / 2, y, (W + b1W) / 2, y + b1H);
        mainButton(c, restartR, again, 25f, pressed == ID_RESTART, padV1);
        y += b1H;

        y += mt;
        backR.set((W - b2W) / 2, y, (W + b2W) / 2, y + b2H);
        mainButton(c, backR, menu, 17f, pressed == ID_BACK, 10f);
    }
}
